a= int(input())
b= int(input())
sum= a+b
print ("X =",sum)