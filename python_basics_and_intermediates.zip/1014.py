X = int(input())
Y = float(input())

avg = X/Y

print("%0.3f km/l" %avg )