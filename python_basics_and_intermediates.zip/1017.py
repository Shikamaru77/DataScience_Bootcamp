time = int(input())
avg = int(input())
d = avg * time
fuel = d / 12

print('%0.3f'%fuel)