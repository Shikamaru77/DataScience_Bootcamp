R= float(input())
n=3.14159
A= (n*(R*R))
#print("A=",round(A,4))
print("A=%.4f" %A)