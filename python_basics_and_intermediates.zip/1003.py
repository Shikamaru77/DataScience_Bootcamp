a= int(input())
b= int(input())
sum= a+b
print ("SOMA = %d"%sum)