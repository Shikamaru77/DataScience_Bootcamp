a= float(input())*3.5
b= float(input())*7.5
print("MEDIA = %.5f"%float((a+b)/(3.5+7.5)))