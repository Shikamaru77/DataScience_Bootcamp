a= float(input())*2
b= float(input())*3
c= float(input())*5
print("MEDIA = %.1f"%float((a+b+c)/(10)))