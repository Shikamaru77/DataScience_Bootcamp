a= int(input())
b= int(input())
sum= a*b
print ("PROD = %d"%sum)