a= input()
b= float(input())
c= float(input())*0.15
#d= int(input())
#print("NUMBER =",a)
print("TOTAL = R$ %.2f"%(b+c))